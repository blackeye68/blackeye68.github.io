# Obnoxious Quiz
Interactive quiz with obnoxious sound effects. Use with caution, people get irate about unexpected sound on web pages. Use the Interactive Quiz for a silent version to ruffle fewer feathers.
